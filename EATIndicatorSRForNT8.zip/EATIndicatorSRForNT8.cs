#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private EATIndicatorSRForNT8[] cacheEATIndicatorSRForNT8;

		
		public EATIndicatorSRForNT8 EATIndicatorSRForNT8()
		{
			return EATIndicatorSRForNT8(Input);
		}


		
		public EATIndicatorSRForNT8 EATIndicatorSRForNT8(ISeries<double> input)
		{
			if (cacheEATIndicatorSRForNT8 != null)
				for (int idx = 0; idx < cacheEATIndicatorSRForNT8.Length; idx++)
					if ( cacheEATIndicatorSRForNT8[idx].EqualsInput(input))
						return cacheEATIndicatorSRForNT8[idx];
			return CacheIndicator<EATIndicatorSRForNT8>(new EATIndicatorSRForNT8(), input, ref cacheEATIndicatorSRForNT8);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.EATIndicatorSRForNT8 EATIndicatorSRForNT8()
		{
			return indicator.EATIndicatorSRForNT8(Input);
		}


		
		public Indicators.EATIndicatorSRForNT8 EATIndicatorSRForNT8(ISeries<double> input )
		{
			return indicator.EATIndicatorSRForNT8(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.EATIndicatorSRForNT8 EATIndicatorSRForNT8()
		{
			return indicator.EATIndicatorSRForNT8(Input);
		}


		
		public Indicators.EATIndicatorSRForNT8 EATIndicatorSRForNT8(ISeries<double> input )
		{
			return indicator.EATIndicatorSRForNT8(input);
		}

	}
}

#endregion
