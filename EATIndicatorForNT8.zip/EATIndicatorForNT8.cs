#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private EATIndicatorForNT8[] cacheEATIndicatorForNT8;

		
		public EATIndicatorForNT8 EATIndicatorForNT8()
		{
			return EATIndicatorForNT8(Input);
		}


		
		public EATIndicatorForNT8 EATIndicatorForNT8(ISeries<double> input)
		{
			if (cacheEATIndicatorForNT8 != null)
				for (int idx = 0; idx < cacheEATIndicatorForNT8.Length; idx++)
					if ( cacheEATIndicatorForNT8[idx].EqualsInput(input))
						return cacheEATIndicatorForNT8[idx];
			return CacheIndicator<EATIndicatorForNT8>(new EATIndicatorForNT8(), input, ref cacheEATIndicatorForNT8);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.EATIndicatorForNT8 EATIndicatorForNT8()
		{
			return indicator.EATIndicatorForNT8(Input);
		}


		
		public Indicators.EATIndicatorForNT8 EATIndicatorForNT8(ISeries<double> input )
		{
			return indicator.EATIndicatorForNT8(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.EATIndicatorForNT8 EATIndicatorForNT8()
		{
			return indicator.EATIndicatorForNT8(Input);
		}


		
		public Indicators.EATIndicatorForNT8 EATIndicatorForNT8(ISeries<double> input )
		{
			return indicator.EATIndicatorForNT8(input);
		}

	}
}

#endregion
